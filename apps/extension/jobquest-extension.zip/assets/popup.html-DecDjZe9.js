(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{key:`linkedin`,hostname:`linkedin.com`,useJsonLd:!1,dom:{title:{primary:`a[href*="/jobs/view/"]`,fallback:`.job-details-jobs-unified-top-card__job-title`},company:{primary:`a[href*="/company/"]`,fallback:`.job-details-jobs-unified-top-card__company-name`},location:{primary:`a[href*="/company/"] ~ span`,fallback:`span._3df0079a._1d9c1239`},description:{primary:`[data-testid="expandable-text-box"]`}}},{key:`wuzzuf`,hostname:`wuzzuf.net`,useJsonLd:!0,dom:{title:{primary:`h1`},company:{primary:`a[href*="/jobs/careers/"]`},location:{primary:`strong.css-1vlp604`},description:{primary:`section:nth-of-type(3), section:nth-of-type(4)`}}}];function t(t){let n=t.toLowerCase();return e.find(e=>n===e.hostname||n.endsWith(`.`+e.hostname))??null}function n(e){let t=e=>(e||``).replace(/\s+/g,` `).trim(),n=e=>{if(!e)return``;try{let n=new DOMParser().parseFromString(e,`text/html`);return t(n.body.textContent||``)}catch{return t(e.replace(/<[^>]*>/g,` `))}},r=e=>{if(!e)return``;try{let n=document.querySelector(e);return n?t(n.textContent||``):``}catch{return``}},i={title:{value:``,usedFallback:!1},company:{value:``,usedFallback:!1},location:{value:``,usedFallback:!1},description:{value:``,usedFallback:!1}};if(e.useJsonLd){let e=Array.from(document.querySelectorAll(`script[type="application/ld+json"]`)),r=null;for(let t of e)try{let e=JSON.parse(t.textContent||``),n=(Array.isArray(e)?e:e&&e[`@graph`]?e[`@graph`]:[e]).find(e=>{let t=e&&e[`@type`];return t===`JobPosting`||Array.isArray(t)&&t.includes(`JobPosting`)});if(n){r=n;break}}catch{}if(r){let e=r.jobLocation&&r.jobLocation.address||{},a=[e.addressRegion,e.addressCountry].filter(Boolean).join(`, `);i.title={value:t(r.title||``),usedFallback:!1},i.company={value:t(r.hiringOrganization&&r.hiringOrganization.name||``),usedFallback:!1},i.location={value:t(a),usedFallback:!1},i.description={value:n(r.description||``),usedFallback:!1}}}let a=(t,n)=>{if(i[t].value)return;let a=r(n.primary);if(a){i[t]={value:a,usedFallback:!!e.useJsonLd};return}let o=n.fallback?r(n.fallback):``;o&&(i[t]={value:o,usedFallback:!0})};return a(`title`,e.dom.title),a(`company`,e.dom.company),a(`location`,e.dom.location),a(`description`,e.dom.description),i}var r=`http://localhost:3000`.replace(/\/$/,``),i=`http://localhost:5200`.replace(/\/$/,``),a=class extends Error{status;constructor(e,t){super(t),this.name=`ApiError`,this.status=e}};async function o(e,t){let n;try{n=await fetch(`${r}/jobs`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t}`},body:JSON.stringify(e)})}catch{throw new a(0,`Network error — is the JobQuest backend running?`)}if(!n.ok){let e=n.statusText;try{let t=await n.json();t?.message&&(e=t.message)}catch{}throw new a(n.status,e)}return await n.json()}var s=`jq_token`;async function c(){return(await chrome.storage.local.get(s))[s]??null}async function l(){await chrome.storage.local.remove(s)}async function u(){let e=chrome.identity.getRedirectURL(),t=`${r}/auth/google?redirect_uri=${encodeURIComponent(e)}`,n=await chrome.identity.launchWebAuthFlow({url:t,interactive:!0});if(!n)throw Error(`Sign-in was cancelled.`);let i=n.split(`#`)[1]??``,a=new URLSearchParams(i).get(`token`);if(!a)throw Error(`No token returned from sign-in.`);return await chrome.storage.local.set({[s]:a}),a}var d=document.querySelector(`#app`),f=null;function p(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}function m(e){return e===`linkedin`?`Extracted from LinkedIn — review & edit`:e===`wuzzuf`?`Wuzzuf — selectors pending, fill in below`:`Manual entry — fill in the fields`}function h(){d.innerHTML=`
    <div class="card center">
      <div class="spinner"></div>
      <p class="muted" style="margin-top:12px">Reading this page…</p>
    </div>`}function g(e){d.innerHTML=`
    <div class="card center">
      <h1 class="brand" style="justify-content:center">🎯 JobQuest</h1>
      <p class="muted" style="margin-top:6px">
        ${p(e??`Sign in to save jobs and earn XP.`)}
      </p>
      <button id="signin" class="btn-primary" style="margin-top:16px">
        🔑 Sign in with Google
      </button>
      <p id="signin-error" class="err"></p>
    </div>`;let t=document.getElementById(`signin`);t.addEventListener(`click`,async()=>{t.disabled=!0,t.textContent=`Opening Google…`;try{f=await u(),w()}catch(e){let n=document.getElementById(`signin-error`);n.textContent=e instanceof Error?e.message:`Sign-in failed.`,t.disabled=!1,t.textContent=`🔑 Sign in with Google`}})}function _(e){let t=e=>e?`<span class="dot" title="Double-check — extracted via a fallback selector"></span>`:``;d.innerHTML=`
    <div class="card">
      <h1 class="brand">🎯 JobQuest</h1>
      <p class="sub">${p(m(e.source))}</p>

      <label for="f-title">Title ${t(e.fallback.title)}</label>
      <input id="f-title" type="text" placeholder="Job title" />

      <label for="f-company">Company ${t(e.fallback.company)}</label>
      <input id="f-company" type="text" placeholder="Company" />

      <label for="f-location">Location ${t(e.fallback.location)}</label>
      <input id="f-location" type="text" placeholder="Location (optional)" />

      <label for="f-description">Description ${t(e.fallback.description)}</label>
      <textarea id="f-description" placeholder="Description (optional)"></textarea>

      <label for="f-url">Job URL</label>
      <input id="f-url" type="text" placeholder="https://…" />

      <button id="save" class="btn-primary">Save to JobQuest</button>
      <p id="form-error" class="err"></p>
    </div>`;let n=(t,n)=>{let r=document.getElementById(t);r.value=e[n],r.addEventListener(`input`,()=>{e[n]=r.value})};n(`f-title`,`title`),n(`f-company`,`company`),n(`f-location`,`location`),n(`f-description`,`description`),n(`f-url`,`url`);let r=document.getElementById(`save`);r.addEventListener(`click`,()=>v(e,r))}async function v(e,t){let n=document.getElementById(`form-error`),r=e.title.trim(),i=e.company.trim(),s=e.url.trim();if(!r||!i||!s){n.textContent=`Title, company and URL are required.`;return}n.textContent=``,t.disabled=!0,t.textContent=`Saving…`;try{y((await o({title:r,company:i,url:s,location:e.location.trim()||void 0,description:e.description.trim()||void 0,source:e.source},f??``)).xpAward)}catch(e){if(e instanceof a&&e.status===409){b();return}if(e instanceof a&&e.status===401){await l(),f=null,g(`Session expired — please sign in again.`);return}n.textContent=e instanceof a?e.message:`Something went wrong. Try again.`,t.disabled=!1,t.textContent=`Save to JobQuest`}}function y(e){let t=e.newAchievements.map(e=>`<span class="chip">${p(e.icon)} ${p(e.title)}</span>`).join(``);d.innerHTML=`
    <div class="card center">
      <div class="emoji">✅</div>
      <p class="big">Saved to JobQuest</p>
      <p class="muted">Now tracked as a saved application.</p>
      <div class="xp-pill">⚡ +${e.xpGained} XP</div>
      ${e.leveledUp?`<p class="levelup">🎉 Level up! You're now level ${e.user.level}</p>`:``}
      ${t?`<div class="chips">${t}</div>`:``}
      ${S()}
      <button id="close" class="btn-ghost">Close</button>
    </div>`,C()}function b(){d.innerHTML=`
    <div class="card center">
      <div class="emoji">📌</div>
      <p class="big">Already saved</p>
      <p class="muted">This job is already in your JobQuest — no duplicate, no double XP.</p>
      ${S()}
      <button id="close" class="btn-ghost">Close</button>
    </div>`,C()}function x(e){d.innerHTML=`
    <div class="card center">
      <div class="emoji">⚠️</div>
      <p class="big">Couldn't read this page</p>
      <p class="muted">Open a job posting and try again.</p>
      <button id="retry" class="btn-primary">Retry</button>
    </div>`,document.getElementById(`retry`).addEventListener(`click`,e)}function S(){return i?`<button id="view" class="btn-primary">View in JobQuest</button>`:``}function C(){let e=document.getElementById(`view`);e&&e.addEventListener(`click`,()=>{chrome.tabs.create({url:`${i}/applications`}),window.close()});let t=document.getElementById(`close`);t&&t.addEventListener(`click`,()=>window.close())}async function w(){if(h(),f=await c(),!f){g();return}try{let[e]=await chrome.tabs.query({active:!0,currentWindow:!0}),r=e?.url??``,i=``;try{i=r?new URL(r).hostname:``}catch{i=``}let a=t(i),o={title:``,company:``,location:``,description:``,url:r,source:a?a.key:`manual`,fallback:{title:!1,company:!1,location:!1,description:!1}};if(a&&e?.id!=null)try{let t=(await chrome.scripting.executeScript({target:{tabId:e.id},func:n,args:[a]}))?.[0]?.result;t&&(o.title=t.title.value,o.company=t.company.value,o.location=t.location.value,o.description=t.description.value,o.fallback={title:t.title.usedFallback,company:t.company.usedFallback,location:t.location.usedFallback,description:t.description.usedFallback})}catch{}_(o)}catch{x(()=>void w())}}w();